﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathLib
{
    public class Calculator
    {
        public int Result { get; set; }
        public void Add(int op1,int op2)
        {
            Result = op1 + op2;
        }
        public void Sub(int op1, int op2)
        {
            Result = op1 - op2;
        }
        public void Mult(int op1, int op2)
        {
            Result = op1 * op2;
        }
        public void Div(int op1, int op2)
        {
            Result = op1 / op2;
        }
    }
}
