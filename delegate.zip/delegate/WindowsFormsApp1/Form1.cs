﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    delegate void ArithmaticOperation(int op1,int op2);
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string fnOpeertor = "";
        private void btn_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(textNum1.Text);
            int num2 = int.Parse(textNum2.Text);

            MathLib.Calculator calc = new MathLib.Calculator();

            switch(fnOpeertor)
            {
                case "+":
                    ArithmaticOperation opn = new ArithmaticOperation(calc.Add);
                    opn(num1,num2);
                    break;
                case "-":
                    calc.Sub(num1,num2);
                    break;
                case "*":
                    calc.Mult(num1,num2);
                    break;
                case "/":
                    calc.Div(num1,num2);
                    break;

            }
            int result = calc.Result;
            lblAns.Text = result.ToString();

        }

        private void cmbOp_SelectedIndexChanged(object sender, EventArgs e)
        {
            fnOpeertor = cmbOp.SelectedItem.ToString();
        }
    }
}
